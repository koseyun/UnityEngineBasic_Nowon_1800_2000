# RGBXYZ
Visualize RGB in XYZ

![rgbToxyz](https://user-images.githubusercontent.com/85269091/185753433-da9ec1bf-15a9-4346-ad4d-1f6ed3a5ba19.gif)
